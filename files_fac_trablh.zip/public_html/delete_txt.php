<?php  
    session_start();  
    if(!$_SESSION['oemail']){  
        header("Location: index.php"); 
    }  
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>3em3 - cPanel</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/shop-item.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ADSUMUS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Início
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">
        <h1 class="my-4"><center></h1></h1>
        <div class="list-group">
      <a href="logout.php" class="list-group-item active"><center>Sair</center></a></a>
          <a href="public_txt.php" class="list-group-item"><center>(C)Criar Postagens</center></a>
          <a href="dash.php" class="list-group-item"><center>(R)Ler Postagens</center></a>
          <a href="update_txt.php" class="list-group-item"><center>(U)Atualizar Postagens</center>
            <a href="delete_txt.php" class="list-group-item"><center>(D)Excluir Postagens</center></a></a>
        </div>
      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div class="card mt-4">
        </div>
        <!-- /.card -->
<form method="POST" action="delete_txt.php">
        <div class="card card-outline-secondary my-4">
          <div class="card-header">
            <center>Excluir Postagens | 3em3</center>
            
          </div>
<br><center><font color="red">Para excluir uma postagem, basta informar o nº Id que aparece ao lado do título da postagem na caixinha abaixo e apertar no "X".</font><br><br>
    <input type="text" style="width: 30px; height: 30px; margin-top: -30px;" name="id_postagein">
    <input type="submit" name="delthisokk" value="X" style="background-color: #000; border-color: #000; color: red;">
</center>

<div class="card card-outline-secondary my-4">
<table>
<thead>
<tr>
<?php  
$connect_mysql = mysql_connect("localhost", "id15534241_carlindoroot", "cvtsV1G>o5Igu6Mz");
mysql_select_db("id15534241_obancoinho", $connect_mysql) or die(mysql_error());
$run = mysql_query("SELECT * FROM blog  WHERE id ORDER BY id DESC", $connect_mysql);  
  
    while($row = mysql_fetch_array($run))  
{  
$titulo=$row[1];  
$texto=$row[2];  
$id_tela=$row[0];
?>
  <th class="card-header"><center><?php echo $titulo; ?> ||  <?php echo "<b><font color='blue'>Id: $id_tela</font></b>"; ?>
    </center></th>
</tr>
</thead>


<tr>  
<td class="card-body"><center><?php echo $texto; ?></center></td>  
</tr>  
<?php } ?>
</table>
</div>

<?php 
if(isset($_POST['delthisokk'])){
//$connect_mysqli = mysql_connect("localhost", "root", "");
$verID = $_POST['id_postagein'];
$delet = mysql_query("DELETE FROM `blog` WHERE `blog`.`id` = '$verID'");
echo "<script>alert('Exclusão realizada com sucesso! Referente à postagem: $verID.');</script>";
echo "<meta http-equiv='refresh' content='1;URL=delete_txt.php'>";
}
  ?>
</form>
        <!-- /.card -->

      </div>
      <!-- /.col-lg-9 -->

    </div>

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; 3em3 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>