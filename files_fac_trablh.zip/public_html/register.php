<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>3em3 - Register</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/shop-item.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ADSUMUS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Início
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Sobre Nós</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="register.php">Registro</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">
        
      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div class="card mt-4">
          <div class="card-body">
            <h3 class="card-title"><center>Seja Bem Vindo(a)!</center></h3>
          </div>
        </div>
        <!-- /.card -->

        <div class="card card-outline-secondary my-4">
          <div class="card-header">
            <center>Área de Registro - 3em3</center>
          </div>
          <div class="card-body">
            <center>
                <form method="POST" action="register.php">
                  <fieldset>
                  Cadastre seu Login.: <input type="text" name="oemail" required><br><br>
                  Cadastre sua senha.: <input type="password" name="asenha" required><br><br>
                  Já possui cadastro? <a href="login.php" >clique aqui</a><br>
                  </fieldset><br>
<?php 
if(isset($_POST['avnc'])){  
    
    $connect_mysql = mysql_connect("localhost", "id15534241_carlindoroot", "cvtsV1G>o5Igu6Mz");
    mysql_select_db("id15534241_obancoinho", $connect_mysql) or die(mysql_error());

    $email = $_POST['oemail'];  
    $senha = $_POST['asenha'];  
    
    $consulta = mysql_query("SELECT * FROM db WHERE login='$email'", $connect_mysql); 
  
    if(mysql_num_rows($consulta))  
    {  
        echo "<center><font color='RED'>Login ja cadastrado em nosso sistema, tente novamente!</font></center>";  
        echo "<meta http-equiv='refresh' content='2;URL=register.php'>";
    }  
    else  
    {  
       $cadastro = mysql_query("INSERT INTO `db` (`id`, `login`, `senha`) VALUES (NULL,'$email', '$senha');") or die(mysql_error());

        echo "<center><font color='LIME'>Usuario cadastrado com sucesso, transferindo para area do usuário.</font></center>"; 

        echo "<meta http-equiv='refresh' content='1;URL=dash.php'>";
        $_SESSION['oemail']=$email;   
    }      
}  
?>   
                  <input type="submit" name="avnc" value="Registrar-me" class="btn btn-success">
                </form>
            </center>
          </div>
        </div>
        <!-- /.card -->

      </div>
      <!-- /.col-lg-9 -->

    </div>

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; 3em3 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
