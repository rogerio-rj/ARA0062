<?php  
    session_start();  
    if(!$_SESSION['oemail']){  
        header("Location: index.php"); 
    }  
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>3em3 - cPanel</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/shop-item.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ADSUMUS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Início
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <div class="row">

      <div class="col-lg-3">
        <h1 class="my-4"><center></h1></h1>
        <div class="list-group">
      <a href="logout.php" class="list-group-item active"><center>Sair</center></a></a>
          <a href="public_txt.php" class="list-group-item"><center>(C)Criar Postagens</center></a>
          <a href="dash.php" class="list-group-item"><center>(R)Ler Postagens</center></a>
          <a href="update_txt.php" class="list-group-item"><center>(U)Atualizar Postagens</center>
            <a href="delete_txt.php" class="list-group-item"><center>(D)Excluir Postagens</center></a></a>
        </div>
      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div class="card mt-4">
        </div>
        <!-- /.card -->

        <div class="card card-outline-secondary my-4">
          <div class="card-header">
            <center>Área de Atualizações de Postagens | Administrador</center>
          </div>
          <div class="card-body">
<form method="POST" action="update_txt.php">
                  <CENTER><B>
						<FONT COLOR="RED"> PARA REALIZAR UMA ATUALIZAÇÃO BASTA INFORMAR O TÍTULO, CORPO DO TEXTO E O Nº ID REFERENTE A POSTAGEM QUE DESEJA ALTERAR E APERTAR EM "<FONT COLOR="LIME">ATUALIZAR POSTAGEM</FONT>".</FONT>                  	
                  </B></CENTER><BR><fieldset>
                  Informe o nº da ID.: <input type="text" style="width: 30px; height: 30px; margin-top: -30px;" name="id_postagein" required>
                  Título da Postagem.: <input type="text" name="oemail" required><br><br>
                  Informe o Corpo da Postagem.: <br><textarea style="width: 510px; height: 80px; resize: none;" name="asenha" required></textarea><br>
                  </fieldset><br>
<?php 
if(isset($_POST['id_postagein'])){  
    
    $connect_mysql = mysql_connect("localhost", "id15534241_carlindoroot", "cvtsV1G>o5Igu6Mz");
    mysql_select_db("id15534241_obancoinho", $connect_mysql) or die(mysql_error());

    $verID = $_POST['id_postagein'];

    $titulo = $_POST['oemail'];  
    $postagem = $_POST['asenha'];   
    
    $att_db = mysql_query("UPDATE blog SET titulo = '$titulo', corpo = '$postagem' WHERE blog.id = '$verID'");

    echo "<script>alert('POSTAGEM ATUALIZADA COM SUCESSO!! Referente à publicação: $verID.');</script>"; 

    echo "<meta http-equiv='refresh' content='1;URL=update_txt.php'>";  

    }    
?>   
                  <input type="submit" name="avnc" value="Atualizar Postagem" class="btn btn-success">
                
<div class="panel panel-default"><br>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-hover" border="1">
                                    <thead>
                                        <tr>
                                        	<th>#Nº ID</th>
                                        	<th> Título</th>
                                            <th> Corpo da Postagem</th>
                                        </tr>
                                    </thead>
<?php  
    $connect_mysql = mysql_connect("localhost", "id15534241_carlindoroot", "cvtsV1G>o5Igu6Mz");
    mysql_select_db("id15534241_obancoinho", $connect_mysql) or die(mysql_error());

    $run = mysql_query("SELECT * FROM blog WHERE id", $connect_mysql);  
  
    while($row = mysql_fetch_array($run))  
        {  
            $num_process=$row[1];  
            $valor_sac=$row[2];  
  			$idnum = $row[0];
        ?>

                                        <tr>  
                                            <!--here showing results in the table -->  
                                            <td><FONT COLOR="BLUE"><?php echo $idnum; ?></FONT></td>
                                            <td><?php echo $num_process;  ?></td>  
                                            <td><?php echo $valor_sac;  ?></td>
                                        </tr>  
<?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>

                </form>
          </div>
        </div>
        <!-- /.card -->

      </div>
      <!-- /.col-lg-9 -->

    </div>

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; 3em3 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

