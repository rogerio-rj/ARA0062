<?php 

phpinfo()

?>